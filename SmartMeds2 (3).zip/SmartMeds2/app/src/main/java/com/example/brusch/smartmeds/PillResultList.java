package com.example.brusch.smartmeds;


import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;


/**
 * A simple {@link Fragment} subclass.
 */
public class PillResultList extends ListFragment {

    public String id, name, inscription, color, shape;

    public PillResultList() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        new allSearchPills().execute("");

        return super.onCreateView(inflater, container, savedInstanceState);
    }



    @Override
    public void onListItemClick(ListView l, View v, int position, long id){
        super.onListItemClick(l, v, position, id);
        Log.d("test","ListView Position: "+position+" - id: "+id);
        MainActivity ma = (MainActivity)getActivity();
        ma.populatePill(id);
    }

    public void setParameters(String _name, String _inscription, String _color, String _shape) {
        this.name = _name;
        this.inscription = _inscription;

        if(_color.equals("Pill Color"))
            this.color = "";
        else
            this.color = _color;

        if(_shape.equals("Pill Shape"))
            this.shape = "";
        else
            this.shape = _shape;
    }


    public class allSearchPills extends AsyncTask<String, Integer, Cursor> {

        @Override
        protected Cursor doInBackground(String... params){
            Log.d("test","PillResultList - allSearchPills1");
            DatabaseHelper dbh = new DatabaseHelper(getActivity(),"Pill",null,1);
            Cursor cursor = dbh.searchPill(name, inscription, color, shape);
            return cursor;
        }

        @Override
        protected void onPostExecute(Cursor cursor){
            super.onPostExecute(cursor);

            String[] columns = new String[] {"name"};
            int[] views = new int[] {android.R.id.text1};
            SimpleCursorAdapter adapter =
                    new SimpleCursorAdapter(getActivity(),android.R.layout.simple_list_item_1,
                            cursor,columns,views,
                            CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
            setListAdapter(adapter);
        }
    }

}



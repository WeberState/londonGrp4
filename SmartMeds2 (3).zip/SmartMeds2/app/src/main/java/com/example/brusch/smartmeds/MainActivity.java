package com.example.brusch.smartmeds;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().getDecorView().setBackgroundColor(Color.parseColor("#177c61"));

        if(savedInstanceState==null){
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container1, new MainMenu(), "MainMenu_Fragment")
                .addToBackStack(null)
                .commit();
        }
    }

    public void allSearchPill(String name, String inscription, String color, String shape) {
        PillResultList prl = new PillResultList();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container1, prl, "prl")
                .addToBackStack(null)
                .commit();
        prl.setParameters(name, inscription, color, shape);
    }

    public void populatePill(long id) {
        Log.d("test","Main Activity - populatePill : "+id);
        PillResult pr = new PillResult();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container1, pr, "pr")
                .addToBackStack(null)
                .commit();
        pr.populatePill(id);
    }
}

package com.example.brusch.smartmeds;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

/**
 * A simple {@link Fragment} subclass.
 */
public class MainMenu extends Fragment {

    View rootView;

    Spinner spinner_PillColor, spinner_PillShape;

    EditText editText_PillName, editText_PillInscription;

    Button button_AllSearch;

    public MainMenu() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_main_menu, container, false);

        editText_PillName = (EditText) rootView.findViewById(R.id.editText_PillName);
        editText_PillInscription = (EditText) rootView.findViewById(R.id.editText_PillInscription);

        button_AllSearch = (Button) rootView.findViewById(R.id.button_AllSearch);

        spinner_PillColor = (Spinner) rootView.findViewById(R.id.spinner_PillColor);
        ArrayAdapter<String> adapter_PillColor = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.array_PillColors));
        adapter_PillColor.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_PillColor.setAdapter(adapter_PillColor);
        // set default position for hint
        spinner_PillColor.setSelection(0);

        spinner_PillShape = (Spinner) rootView.findViewById(R.id.spinner_PillShape);
        ArrayAdapter<String> adapter_PillShape = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.array_PillShapes));
        adapter_PillShape.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_PillShape.setAdapter(adapter_PillShape);
        // set default position for hint
        spinner_PillShape.setSelection(0);

        button_AllSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity ma = (MainActivity) getActivity();
                ma.allSearchPill(editText_PillName.getText().toString(),
                        editText_PillInscription.getText().toString(),
                        spinner_PillColor.getSelectedItem().toString(),
                        spinner_PillShape.getSelectedItem().toString());
            }
        });
        return rootView;
    }
}

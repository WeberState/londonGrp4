package com.example.brusch.smartmeds;

import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class PillResult extends Fragment {

    TextView edit_id, edit_name, edit_inscription, edit_color, edit_shape, edit_strength;

    public long _id;

    public String id, name, inscription, color, shape;

    public String search_id, search_name, search_inscription, search_color, search_shape, search_strength;

    public Button btnNewSearch;

    public PillResult() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_pill_result, container, false);
        Log.d("test","PillResult - onCreateView");

        edit_id = (TextView) rootView.findViewById(R.id.edit_id);
        edit_name = (TextView) rootView.findViewById(R.id.edit_name);
        edit_inscription = (TextView) rootView.findViewById(R.id.edit_inscription);
        edit_color = (TextView) rootView.findViewById(R.id.edit_color);
        edit_shape = (TextView) rootView.findViewById(R.id.edit_shape);
//        edit_strength = (TextView) rootView.findViewById(R.id.edit_strength);

        btnNewSearch = (Button) rootView.findViewById(R.id.btnNewSearch);

        btnNewSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity ma = (MainActivity) getActivity();
                ma.getSupportFragmentManager().beginTransaction()
                        .replace(R.id.container1, new MainMenu(), "mm")
                        .addToBackStack(null)
                        .commit();
            }
        });

        new searchPill().execute("");

        return rootView;
    }

    public void refreshText(){
        Log.d("test","PillResult - refreshText");
        edit_id.setText(search_id);
        edit_name.setText(search_name);
        edit_inscription.setText(search_inscription);
        edit_color.setText(search_color);
        edit_shape.setText(search_shape);
//        edit_strength.setText(search_strength);
    }

    public void populatePill(long id){
        this._id = id;
    }

    public class searchPill extends AsyncTask<String, Integer, Cursor> {

        @Override
        protected Cursor doInBackground(String... params){
            Log.d("test","PillResult - AsyncTask doInBackground");
            DatabaseHelper dbh = new DatabaseHelper(getActivity(),"Pill",null,1);

            Cursor cursor = dbh.searchPill(_id);

            Log.d("test","PillResult - AsyncTask doInBackground1");

            //catch runtimeException
            try {
                cursor.moveToFirst();
                search_id = cursor.getString(cursor.getColumnIndex("_id"));
                search_name = cursor.getString(cursor.getColumnIndex("name"));
                search_inscription = cursor.getString(cursor.getColumnIndex("inscription"));
                search_color = cursor.getString(cursor.getColumnIndex("color"));
                search_shape = cursor.getString(cursor.getColumnIndex("shape"));
//                search_strength = cursor.getString(cursor.getColumnIndex("strength"));
            } catch (RuntimeException e){}

            Log.d("test","PillResult - AsyncTask doInBackground2 name="+search_name+" inscr="+search_inscription
                    +" color="+search_color+" shape="+search_shape);

            return cursor;
        }

        @Override
        protected void onPostExecute(Cursor cursor){
            super.onPostExecute(cursor);
            Log.d("test", "PillResults2 - onPostExecute");
            refreshText();
        }
    }
}

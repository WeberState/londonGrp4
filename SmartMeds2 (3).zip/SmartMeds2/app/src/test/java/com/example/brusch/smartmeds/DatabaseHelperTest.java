//package com.example.brusch.smartmeds;
//
////import android.provider.ContactsContract;
////import android.test.AndroidTestCase;
////import android.test.RenamingDelegatingContext;
////
////import android.support.test.InstrumentationRegistry;
////import android.support.test.runner.AndroidJUnit4;
////import android.test.suitebuilder.annotation.LargeTest;
////
////import org.junit.Before;
////import org.junit.After;
////import org.junit.Test;
////import org.junit.runner.RunWith;
////
////import java.util.List;
////
////import static junit.framework.Assert.assertNotNull;
////import static junit.framework.Assert.assertTrue;
////import static org.hamcrest.CoreMatchers.is;
////import static org.hamcrest.MatcherAssert.assertThat;
////
////import static org.junit.Assert.*;
//
//import org.junit.After;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.robolectric.RobolectricGradleTestRunner;
//import org.robolectric.RuntimeEnvironment;
//import org.robolectric.annotation.Config;
//
//import static android.os.Build.VERSION_CODES.LOLLIPOP;
//import static junit.framework.Assert.assertEquals;
//
///**
// * Created by 212669849 on 11/14/2017.
// */
////@RunWith(AndroidJUnit4.class)
////@android.support.test.filters.LargeTest
//@RunWith(RobolectricGradleTestRunner::class)
//@Config(constants = BuildConfig::class, sdk = intArrayOf(LOLLIPOP), packageName = "com.example.brusch.smartmeds")
//public class DatabaseHelperTest{
//
//   DatabaseHelper dbh; // Your DbHelper class
//
//
//
//
//
//
//    @Test
//    public void insertPill() throws Exception {
//
//    }
//
//    @Test
//    public void getOnePill() throws Exception {
//
//    }
//
//    @Test
//    public void searchPill() throws Exception {
//            assertEquals(4, 2+2);
//    }
//
//
//}